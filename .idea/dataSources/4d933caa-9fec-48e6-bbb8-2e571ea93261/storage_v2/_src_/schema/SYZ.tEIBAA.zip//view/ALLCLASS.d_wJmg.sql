create view ALLCLASS as
select "XH","XM","ZONGCE" from student_zongce
/

