create view SANHAO as
select zhiyu.xh,zhiyu.xm,kcms,shuziluoji,renshishixi,makesi,jiaobenyuyankeshe,daxuewuli_two,maozedong,tiyu_three
szshiyan,ruanjiangongcheng,tiyu_four,zhiyeshengya,daxuewulishiyan,cplusplus,gailvlun,daxueyingyu_three,jizu,jiaoben,
xiandai,shujuku,net,shujukukeshe,netkeshe,shixun,chuangye,cpluspluskeshe,average,total_score,xuefen,pingjunjidian,paiming from student_zhiyu zhiyu,student_zongce zongce where zhiyu.xh=zongce.xh
/

