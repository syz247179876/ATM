create view ZONGCE as
select "XH","XM","ZONGCE" from student_zongce
/

